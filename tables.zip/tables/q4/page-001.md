# q4 results

Page 1 of 1 | Total data rows: 47

[Back to report](../../REPORT.md)

| nconst | excellent | other_count | other_mean | excellent_film | primaryName |
| --- | --- | --- | --- | --- | --- |
| nm0204628 | 1 | 2 | 5.65 | tt3741834 | Garth Davis |
| nm0449984 | 1 | 9 | 5.944444444444444 | tt0080684 | Irvin Kershner |
| nm1749112 | 1 | 3 | 5.7 | tt0808417 | Vincent Paronnaud |
| nm6044360 | 1 | 2 | 5.95 | tt5504168 | Ravikanth Perepu |
| nm0446819 | 1 | 2 | 5.449999999999999 | tt0246578 | Richard Kelly |
| nm0536705 | 1 | 4 | 5.15 | tt21108804 | Ananth Mahadevan |
| nm8678191 | 1 | 2 | 5.15 | tt6380520 | Karthick Naren |
| nm0149134 | 1 | 7 | 4.8428571428571425 | tt0263208 | Sinan Çetin |
| nm0244892 | 1 | 4 | 5.325 | tt0118751 | J.P. Dutta |
| nm0500896 | 1 | 4 | 5.85 | tt0380275 | David Leland |
| nm2134474 | 1 | 6 | 5.833333333333333 | tt3322420 | Vikas Bahl |
| nm0002239 | 1 | 2 | 4.9 | tt0093970 | Prince |
| nm0092632 | 1 | 2 | 5.85 | tt0282864 | Carlos Bolado |
| nm0846092 | 1 | 4 | 5.525 | tt0416960 | Kamal Tabrizi |
| nm1434372 | 1 | 2 | 5.8 | tt0377575 | Johny Antony |
| nm0000671 | 1 | 3 | 5.933333333333334 | tt0117666 | Billy Bob Thornton |
| nm0132709 | 1 | 16 | 5.91875 | tt0381061 | Martin Campbell |
| nm9511013 | 1 | 2 | 5.8 | tt32134802 | Satish Paramvedha |
| nm0031342 | 1 | 5 | 5.7 | tt10554232 | Predrag Antonijevic |
| nm0700872 | 1 | 18 | 5.800000000000001 | tt0816258 | Puri Jagannadh |
| nm0761522 | 1 | 2 | 5.6 | tt0065687 | Denis Sanders |
| nm0796117 | 1 | 15 | 5.866666666666666 | tt0167404 | M. Night Shyamalan |
| nm0803350 | 1 | 4 | 5.25 | tt0290937 | Sangeeth Sivan |
| nm1703622 | 1 | 3 | 5.833333333333333 | tt0220656 | R. Madhesh |
| nm16275551 | 1 | 2 | 5.8 | tt32134802 | Sateesh Paramveda |
| nm1318819 | 1 | 2 | 4.55 | tt1517561 | Ezhil |
| nm2259353 | 1 | 2 | 5.6 | tt7638556 | Christopher Ashley |
| nm0348015 | 1 | 6 | 5.383333333333333 | tt0366840 | Gunasekhar |
| nm1084488 | 1 | 6 | 5.583333333333333 | tt2283748 | Umesh Shukla |
| nm0001675 | 1 | 22 | 5.9409090909090905 | tt0401792 | Robert Rodriguez |
| nm1048560 | 1 | 2 | 5.449999999999999 | tt35445387 | Marcus Raboy |
| nm0735879 | 1 | 2 | 5.949999999999999 | tt0044560 | Ismael Rodríguez |
| nm5650589 | 1 | 2 | 5.95 | tt2877108 | Nalan Kumarasamy |
| nm0536299 | 1 | 4 | 5.800000000000001 | tt0093970 | Albert Magnoli |
| nm6252943 | 1 | 2 | 5.75 | tt36853476 | Harish Vyas |
| nm2735803 | 1 | 2 | 5.9 | tt39150248 | Saurabh Varma |
| nm5120912 | 1 | 3 | 4.633333333333333 | tt8144834 | Ajay Bahl |
| nm0890864 | 1 | 5 | 5.24 | tt1339248 | P. Vasu |
| nm1359360 | 1 | 5 | 5.4399999999999995 | tt0422320 | Dharani |
| nm0574625 | 1 | 4 | 5.975 | tt0434409 | James McTeigue |
| nm0490487 | 1 | 21 | 5.995238095238095 | tt0338564 | Wai Keung Lau |
| nm0588340 | 1 | 2 | 5.65 | tt0401792 | Frank Miller |
| nm0062614 | 1 | 6 | 5.3 | tt6246170 | Harry Baweja |
| nm3607398 | 1 | 5 | 5.96 | tt4047112 | Suseenthiran |
| nm0853238 | 1 | 6 | 5.883333333333333 | tt1454029 | Tate Taylor |
| nm1729063 | 1 | 3 | 5.900000000000001 | tt0425333 | Mert Baykal |
| nm0389514 | 1 | 2 | 4.6 | tt0093970 | David Hogan |

[Back to report](../../REPORT.md)
